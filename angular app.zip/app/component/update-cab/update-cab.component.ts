import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Cab } from 'src/app/model/cab';
import { CabServiceService } from 'src/app/service/cab-service.service';

@Component({
  selector: 'app-update-cab',
  templateUrl: './update-cab.component.html',
  styleUrls: ['./update-cab.component.css']
})
export class UpdateCabComponent implements OnInit {
  cabId: number;
  cab: Cab=new Cab();
  constructor(private cabService: CabServiceService, private route: ActivatedRoute,
              private router: Router) { }

  ngOnInit() {
    this.cabId=this.route.snapshot.params['cabId'];
  }

  onSubmit() {
    this.cabService.updateCab(this.cabId, this.cab).subscribe( data => {
      this.goToCabList();
    },
    error => console.log(error));
  }

  goToCabList() {
    this.router.navigate(["cabs"]);
  }
}


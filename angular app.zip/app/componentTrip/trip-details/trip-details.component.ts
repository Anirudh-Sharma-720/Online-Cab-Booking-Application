import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TripBooking } from 'src/app/model/trip-booking';
import { TripServiceService } from 'src/app/service/trip-service.service';

@Component({
  selector: 'app-trip-details',
  templateUrl: './trip-details.component.html',
  styleUrls: ['./trip-details.component.css']
})
export class TripDetailsComponent implements OnInit {

  id: number;
  trip: TripBooking = new TripBooking();

  constructor(private route: ActivatedRoute, private tripService: TripServiceService) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];
    console.log(this.id);
    this.tripService.getTripById(this.id).subscribe( data => {
      this.trip = data;
    });
  }


}

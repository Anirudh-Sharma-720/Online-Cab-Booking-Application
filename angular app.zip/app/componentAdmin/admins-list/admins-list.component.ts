import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Admin } from 'src/app/model/admin';
import { AdminServiceService } from 'src/app/service/admin-service.service';

@Component({
  selector: 'app-admins-list',
  templateUrl: './admins-list.component.html',
  styleUrls: ['./admins-list.component.css']
})
export class AdminsListComponent implements OnInit {
admins:Admin[];


  constructor(private adminServ:AdminServiceService,private router:Router) { }

  ngOnInit() :void{
    this.getAdminList();
  }
  private getAdminList(){
    this.adminServ.getAdminList().subscribe(
      data=>
      {this.admins=data;
    }
    );
  }
  updateAdmin(userId:number){
    this.router.navigate(['update-admin',userId]);
  }

  deleteAdmin(userId:number){
    this.adminServ.deleteAdmin(userId).subscribe(
      data=>{
        console.log(data);
        this.getAdminList();
      }
    );
  }
  viewAdmin(userId:number){
    this.router.navigate(['view-admin',userId]);
  }
}


import { Driver } from "./driver";
import { Cab } from "./cab";
export class TripBooking {
    tripBookingId: number;
	customerId: number;
    cab:Cab;
    driver:Driver;
	fromLocation: string;
	toLocation: string;
	fromDateTime: Date;
	toDateTime: Date;
	status: boolean;
	distanceInKm: number;
	bill: number;
}

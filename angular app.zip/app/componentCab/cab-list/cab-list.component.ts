import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Cab } from 'src/app/model/cab';
import { CabServiceService } from 'src/app/service/cab-service.service';

@Component({
  selector: 'app-cab-list',
  templateUrl: './cab-list.component.html',
  styleUrls: ['./cab-list.component.css']
})
export class CabListComponent implements OnInit {
  cabs: Cab[];
  
  constructor(private cabService: CabServiceService, private router: Router) { }

  ngOnInit(): void {
    this.getCabs();
  }

  private getCabs() {
    this.cabService.getCabList().subscribe(data => {
      this.cabs=data;
    });
  }

  updateCab(cabId: number) {
    this.router.navigate(["update-cab", cabId]);
  }

  deleteCab(cabId: number) {
    this.cabService.deleteCab(cabId).subscribe(data => {
      console.log(data);
      this.getCabs();
    });
  }
}

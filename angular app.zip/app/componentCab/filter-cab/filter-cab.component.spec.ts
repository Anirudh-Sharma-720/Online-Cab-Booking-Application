import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FilterCabComponent } from './filter-cab.component';

describe('FilterCabComponent', () => {
  let component: FilterCabComponent;
  let fixture: ComponentFixture<FilterCabComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FilterCabComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FilterCabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

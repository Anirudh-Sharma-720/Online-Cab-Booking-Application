import { Driver } from "./driver";

export class Cab {
    cabId: number;
    carType: string;
    perKmRate: number;
    
    
}
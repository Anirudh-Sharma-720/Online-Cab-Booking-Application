import { TestBed } from '@angular/core/testing';

import { CabServiceService } from './cab-service.service';

describe('CabServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CabServiceService = TestBed.get(CabServiceService);
    expect(service).toBeTruthy();
  });
});

import { AbstractUser } from "./abstract-user";

export class Customer extends AbstractUser{
    customerId: number;
    
   
}

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Admin } from 'src/app/model/admin';
import { AppComponent } from 'src/app/app.component';
import { AdminServiceService } from 'src/app/service/admin-service.service';

@Component({
  selector: 'app-admin-interface',
  templateUrl: './admin-interface.component.html',
  styleUrls: ['./admin-interface.component.css']
})
export class AdminInterfaceComponent implements OnInit {
id:number;
adm:Admin=new Admin();
  constructor(private router:Router,private route:ActivatedRoute,private adminServ:AdminServiceService) { }

  ngOnInit() {
    this.id=this.route.snapshot.params['id'];
   
  }
  cabPage(){
    this.router.navigate(['cabs']);
  }
  adminPage(){
    this.router.navigate(['admins']);
  }
  driverPage(){
    this.router.navigate(['drivers']);
  }
  tripPage(){
    this.router.navigate(['trips']);
  }
  customerPage(){
    this.router.navigate(['customers']);
  }
getAdmin(){
  this.adminServ.getAdminById(this.id).subscribe(

    data=>{
      this.adm=data;
      console.log(this.adm);
      this.router.navigate(['view-admin/',this.id]);
    },err=>{
      console.log(err);
    }
  )
}
updateAdmin(){
  this.router.navigate(['update-admin/',this.id]);
}
createAdmin(){
  this.router.navigate(['create-admin']);

}
createCustomer(){
  this.router.navigate(['create-customer']);
}
createDriver(){
  this.router.navigate(['create-driver']);

}
createTrip(){
  this.router.navigate(['create-trip']);
}
createCab(){
  this.router.navigate(['add-cab']);

}

}

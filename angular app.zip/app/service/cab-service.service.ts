import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Cab } from '../model/cab';
import { ProjectUrl } from '../project-url';

@Injectable({
  providedIn: 'root'
})
export class CabServiceService {
  private url=ProjectUrl.getUrl();

  constructor(private httpClient: HttpClient) { }

  getCabList(): Observable<Cab[]> {
    return this.httpClient.get<Cab[]>(`${this.url}`+`cab/v1/cab/viewAll`);
  }

  createCab(cab: Cab): Observable<Object> {
    return this.httpClient.post(`${this.url}`+`cab/v1/cab/insert`, cab);
  }

  updateCab(cabId: number, cab: Cab): Observable<Object> {
    return this.httpClient.put(`${this.url}`+`cab/v1/cab/update/${cabId}`, cab);
  }

  deleteCab(cabId: number): Observable<Object> {
    return this.httpClient.delete(`${this.url}`+`cab/v1/cab/delete/${cabId}`);
  }

  getCabByType(cabType: string): Observable<Cab[]> {
    return this.httpClient.get<Cab[]>(`${this.url}`+`cab/v1/cab/byType/${cabType}`);
  }

  countCabsByType(cabType: string): Observable<number> {
    return this.httpClient.get<number>(`${this.url}`+`cab/v1/cab/countBy/${cabType}`);
  }
  getCabById(id:number):Observable<Cab>{
    return this.httpClient.get<Cab>(`${this.url}cab/v1/cab/getById/${id}`);
  }
}

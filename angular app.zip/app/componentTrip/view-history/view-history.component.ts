import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TripBooking } from 'src/app/model/trip-booking';
import { TripServiceService } from 'src/app/service/trip-service.service';
@Component({
  selector: 'app-view-history',
  templateUrl: './view-history.component.html',
  styleUrls: ['./view-history.component.css']
})
export class ViewHistoryComponent implements OnInit {
trips:TripBooking[]=[];
userId:number;
  constructor(private tripServ:TripServiceService,private route:ActivatedRoute) { }

  ngOnInit() {
    this.userId=this.route.snapshot.params['id'];
    this.tripServ.viewHistory(this.userId).subscribe(data=>{
      this.trips=data;
      console.log(data);
    })
  }


}

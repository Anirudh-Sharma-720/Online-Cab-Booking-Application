import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Customer } from '../model/customer';
import { ProjectUrl } from '../project-url';

@Injectable({
  providedIn: 'root'
})
export class CustomerServiceService {

  baseUrl:String=ProjectUrl.getUrl();
  constructor(private httpClient: HttpClient) { }
 //validation
  validateUser(userName: string, password: string): Observable<Customer> {
    return this.httpClient.get<Customer>(`${this.baseUrl}customer/v1/customer/validate/${userName}&${password}`);
  }
  //get cust by id
  getCustomerByID(id: number){
    return this.httpClient.get<Customer>(`${this.baseUrl}customer/v1/customer/getById/${id}`);
  }
  //add cust
  createCustomer(customer: Customer): Observable<Object> {
    return this.httpClient.post(`${this.baseUrl}customer/v1/customer/insert`,customer);
  }
  //update cust
  updateCustomer(id: number, customer: Customer): Observable<Object>{
    return this.httpClient.put(`${this.baseUrl}customer/v1/customer/update/${id}`, customer);
  }

  //view all cust
  getCustomerList(): Observable<Customer[]> {
    return this.httpClient.get<Customer[]>(`${this.baseUrl}customer/v1/customers`);
  }

  //delete cust
  deleteCustomer(id: number): Observable<Customer>{
    return this.httpClient.delete<Customer>(`${this.baseUrl}customer/v1/customer/delete/${id}`);
  }




}

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Customer } from 'src/app/model/customer';
import { CustomerServiceService } from 'src/app/service/customer-service.service';

@Component({
  selector: 'app-view-customer',
  templateUrl: './view-customer.component.html',
  styleUrls: ['./view-customer.component.css']
})
export class ViewCustomerComponent implements OnInit {

  constructor(private customerService: CustomerServiceService, private route: ActivatedRoute) { }

  id: number;
  customer: Customer = new Customer();
  ngOnInit() {
    this.id = this.route.snapshot.params['id'];
    this.customerService.getCustomerByID(this.id).subscribe(
      response => {this.customer = response;
                    console.log(this.customer)},
      error => {console.error(error);
      }
    )
  }





}

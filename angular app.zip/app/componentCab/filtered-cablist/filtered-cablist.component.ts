import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Cab } from 'src/app/model/cab';
import { CabServiceService } from 'src/app/service/cab-service.service';

@Component({
  selector: 'app-filtered-cablist',
  templateUrl: './filtered-cablist.component.html',
  styleUrls: ['./filtered-cablist.component.css']
})
export class FilteredCablistComponent implements OnInit {
  count: number;
  carType: string;
  cabs: Cab[];
  constructor(private cabService: CabServiceService, private route: ActivatedRoute) { }

  ngOnInit() {
    this.carType=this.route.snapshot.params['carType'];
    this.getCabs();
  }

  getCabs() {
    this.cabService.getCabByType(this.carType).subscribe(data => {
      this.cabs=data;
    });
    this.cabService.countCabsByType(this.carType).subscribe(data => {
      this.count=data;
    });
  }
}

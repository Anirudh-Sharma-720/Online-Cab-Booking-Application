import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Admin } from 'src/app/model/admin';
import { AdminServiceService } from 'src/app/service/admin-service.service';

@Component({
  selector: 'app-create-admin',
  templateUrl: './create-admin.component.html',
  styleUrls: ['./create-admin.component.css']
})
export class CreateAdminComponent implements OnInit {
admin:Admin=new Admin();
  constructor(private admServ:AdminServiceService,private router:Router) { }

  ngOnInit() {
  }
saveAdmin(){
  this.admin.userType="Admin";
  this.admServ.createAdmin(this.admin).subscribe(
    data=>{console.log(data);
    this.getAdminList();
    },err=>{console.log(err);
    }
  );
}
getAdminList(){
  this.router.navigate(['/admins']);
}
  onSubmit(){
console.log(this.admin);
this.saveAdmin();

  }

}

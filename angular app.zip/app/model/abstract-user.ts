export class AbstractUser {
    public userId:number;
    public username:String;
	public password:String;
	public mobileNumber:String;
	public email:String;
    public userType:String;
}

import { Component, OnInit,Input} from '@angular/core';

@Component({
  selector: 'app-app-nav-bar-component',
  templateUrl: './app-nav-bar-component.component.html',
  styleUrls: ['./app-nav-bar-component.component.css']
})

export class AppNavBarComponentComponent {
  collapsed = true;
  toggleCollapsed(): void {
    this.collapsed = !this.collapsed;
  }
}

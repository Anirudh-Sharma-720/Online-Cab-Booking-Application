import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Cab } from 'src/app/model/cab';

@Component({
  selector: 'app-filter-cab',
  templateUrl: './filter-cab.component.html',
  styleUrls: ['./filter-cab.component.css']
})
export class FilterCabComponent implements OnInit {
  cab: Cab=new Cab();
  constructor(private router: Router) { }

  ngOnInit() {
  }
  
  filterCab(carType: string) {
    this.router.navigate(["filterby", carType]);
  }
}

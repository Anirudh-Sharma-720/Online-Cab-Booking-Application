import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { AboutUsComponent } from './component/about-us/about-us.component';
import { AdminInterfaceComponent } from './component/admin-interface/admin-interface.component';

import { LoginComponentComponent } from './component/login-component/login-component.component';
import { UpdateCabComponent } from './component/update-cab/update-cab.component';
import { UserInterfaceComponent } from './component/user-interface/user-interface.component';

import { AdminViewComponent } from './componentAdmin/admin-view/admin-view.component';
import { AdminsListComponent } from './componentAdmin/admins-list/admins-list.component';
import { CreateAdminComponent } from './componentAdmin/create-admin/create-admin.component';
import { UpdateAdminComponent } from './componentAdmin/update-admin/update-admin.component';
import { CabListComponent } from './componentCab/cab-list/cab-list.component';
import { CreateCabComponent } from './componentCab/create-cab/create-cab.component';
import { FilterCabComponent } from './componentCab/filter-cab/filter-cab.component';
import { FilteredCablistComponent } from './componentCab/filtered-cablist/filtered-cablist.component';
import { UserCablistComponent } from './componentCab/user-cablist/user-cablist.component';
import { UserFiltercabComponent } from './componentCab/user-filtercab/user-filtercab.component';
import { UserFiltercablistComponent } from './componentCab/user-filtercablist/user-filtercablist.component';
import { CreateCustomerComponent } from './componentCustomer/create-customer/create-customer.component';
import { CustomerTableComponent } from './componentCustomer/customer-table/customer-table.component';
import { UpdateCustomerComponent } from './componentCustomer/update-customer/update-customer.component';
import { ViewCustomerComponent } from './componentCustomer/view-customer/view-customer.component';
import { CreateDriverComponent } from './componentDriver/create-driver/create-driver.component';
import { DriverDetailsComponent } from './componentDriver/driver-details/driver-details.component';
import { DriverListComponent } from './componentDriver/driver-list/driver-list.component';
import { UpdateDriverComponent } from './componentDriver/update-driver/update-driver.component';
import { CreateTripComponent } from './componentTrip/create-trip/create-trip.component';
import { TripDetailsComponent } from './componentTrip/trip-details/trip-details.component';
import { TripListComponent } from './componentTrip/trip-list/trip-list.component';
import { ViewHistoryComponent } from './componentTrip/view-history/view-history.component';

const routes: Routes = [
  {path:"",component:LoginComponentComponent},
  {path:'admins',component:AdminsListComponent},
  {path:'create-admin' , component:CreateAdminComponent},
  {path:'update-admin/:id',component:UpdateAdminComponent},
  {path: 'view-admin/:id',component:AdminViewComponent},
  {path:"usercabs", component: UserCablistComponent},
  {path:"cabs", component: CabListComponent},
  {path:"update-cab/:cabId", component:UpdateCabComponent},
  {path:"add-cab", component:CreateCabComponent},
  {path:"filter-cab", component: FilterCabComponent},
  {path:"filterby/:carType", component: FilteredCablistComponent},
  {path:"user-filtercab", component: UserFiltercabComponent},
  {path:"user-filtercablist/:carType", component: UserFiltercablistComponent},
  {path:"trips",component:TripListComponent},
  {path:"create-trip",component:CreateTripComponent},
  {path:"create-driver",component:CreateDriverComponent},
   {path:"drivers",component:DriverListComponent},
   {path:"update-driver/:userId",component:UpdateDriverComponent},
   {path:"driver-details/:userId",component:DriverDetailsComponent},
{path:"trip-details/:id",component:TripDetailsComponent},

{path:"create-customer",component:CreateCustomerComponent},
{path:"user-cablist",component:UserCablistComponent},
{path:"customers",component:CustomerTableComponent},
{path:"update-customer/:userId",component:UpdateCustomerComponent},
{path:"view-customer/:id",component:ViewCustomerComponent},
{path:"app-ui",component:AppComponent},
{path:"user-interface/:id",component:UserInterfaceComponent},
{path:"admin-interface/:id",component:AdminInterfaceComponent},
{path:"view-history/:id",component:ViewHistoryComponent},
{path:"about-us",component:AboutUsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

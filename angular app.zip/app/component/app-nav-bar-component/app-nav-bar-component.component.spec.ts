import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppNavBarComponentComponent } from './app-nav-bar-component.component';

describe('AppNavBarComponentComponent', () => {
  let component: AppNavBarComponentComponent;
  let fixture: ComponentFixture<AppNavBarComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppNavBarComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppNavBarComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

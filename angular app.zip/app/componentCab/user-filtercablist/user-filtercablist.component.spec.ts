import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserFiltercablistComponent } from './user-filtercablist.component';

describe('UserFiltercablistComponent', () => {
  let component: UserFiltercablistComponent;
  let fixture: ComponentFixture<UserFiltercablistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserFiltercablistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserFiltercablistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Driver } from 'src/app/model/driver';
import { DriverServiceService } from 'src/app/service/driver-service.service';

@Component({
  selector: 'app-driver-details',
  templateUrl: './driver-details.component.html',
  styleUrls: ['./driver-details.component.css']
})
export class DriverDetailsComponent implements OnInit {
  userId:number;
  driver:Driver;

  constructor(private route:ActivatedRoute, private driverService:DriverServiceService) { }

  ngOnInit() {
    this.userId = this.route.snapshot.params['userId'];
    this.driver = new Driver();
    this.driverService.extractDriver(this.userId).subscribe(data =>{
      this.driver = data;
    });
  }

}

import { Component, OnInit } from '@angular/core';
import { CabServiceService } from 'src/app/service/cab-service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Cab } from 'src/app/model/cab';
import { Customer } from 'src/app/model/customer';
import { CustomerServiceService } from 'src/app/service/customer-service.service';
@Component({
  selector: 'app-user-interface',
  templateUrl: './user-interface.component.html',
  styleUrls: ['./user-interface.component.css']
})
export class UserInterfaceComponent implements OnInit {
id:number;
userid:number;
slides: any[] = new Array(3).fill({id: -1, src: '', title: '', subtitle: ''});
  cabs: Cab[]=[];
  cust:Customer=new Customer();
  cabbb:Cab=new Cab();
  constructor(private router: Router,private route:ActivatedRoute,private cabService:CabServiceService,private custS:CustomerServiceService) { }

  ngOnInit(): void {
    this.id=this.route.snapshot.params['id'];
   // this.router.navigate(['view-customer/',this.id]);
   this.getCabs();
   

  }

  
   getCabs() {
    this.cabService.getCabList().subscribe(data => {
      this.cabs=data;
    });
  }
  bookSUV(cab:Cab){
    this.cabbb.carType='SUV';
    localStorage.setItem('cab',JSON.stringify(this.cabbb));
  this.router.navigate(['create-trip']);
  }
  bookSedan(cab:Cab){
    this.cabbb.carType='Sedan';
    localStorage.setItem('cab',JSON.stringify(this.cabbb));
    this.router.navigate(['create-trip']);
  }
  bookMiniVan(cab:Cab){
    this.cabbb.carType='MiniVan';
    localStorage.setItem('cab',JSON.stringify(this.cabbb));
    this.router.navigate(['create-trip']);
  }
viewHistory(){
this.custS.getCustomerByID(this.userid).subscribe(

  data=>{
    this.cust=data;
    this.router.navigate(['view-history/',this.cust.userId]);
  },err=>{
    console.log(err);
  }
);
}




}

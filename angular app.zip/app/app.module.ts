import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {HttpClientModule} from '@angular/common/http';
import { AdminsListComponent } from './componentAdmin/admins-list/admins-list.component';
import { AppNavBarComponentComponent } from './component/app-nav-bar-component/app-nav-bar-component.component';
import { CreateAdminComponent } from './componentAdmin/create-admin/create-admin.component';
import { FormsModule } from '@angular/forms';
import { UpdateAdminComponent } from './componentAdmin/update-admin/update-admin.component';
import { AdminViewComponent } from './componentAdmin/admin-view/admin-view.component';
import { LoginComponentComponent } from './component/login-component/login-component.component';
import { UserCablistComponent } from './componentCab/user-cablist/user-cablist.component';
import { CabListComponent } from './componentCab/cab-list/cab-list.component';
import { UpdateCabComponent } from './component/update-cab/update-cab.component';
import { CreateCabComponent } from './componentCab/create-cab/create-cab.component';
import { FilterCabComponent } from './componentCab/filter-cab/filter-cab.component';
import { FilteredCablistComponent } from './componentCab/filtered-cablist/filtered-cablist.component';
import { UserFiltercabComponent } from './componentCab/user-filtercab/user-filtercab.component';
import { UserFiltercablistComponent } from './componentCab/user-filtercablist/user-filtercablist.component';
import { CreateTripComponent } from './componentTrip/create-trip/create-trip.component';
import { TripListComponent } from './componentTrip/trip-list/trip-list.component';
import { CreateDriverComponent } from './componentDriver/create-driver/create-driver.component';
import { DriverListComponent } from './componentDriver/driver-list/driver-list.component';
import { UpdateDriverComponent } from './componentDriver/update-driver/update-driver.component';
import { DriverDetailsComponent } from './componentDriver/driver-details/driver-details.component';
import { TripDetailsComponent } from './componentTrip/trip-details/trip-details.component';
import { CreateCustomerComponent } from './componentCustomer/create-customer/create-customer.component';
import { CustomerTableComponent } from './componentCustomer/customer-table/customer-table.component';
import { UpdateCustomerComponent } from './componentCustomer/update-customer/update-customer.component';
import { ViewCustomerComponent } from './componentCustomer/view-customer/view-customer.component';
import { AdminInterfaceComponent } from './component/admin-interface/admin-interface.component';
import { UserInterfaceComponent } from './component/user-interface/user-interface.component';
import { ViewHistoryComponent } from './componentTrip/view-history/view-history.component';
import { AboutUsComponent } from './component/about-us/about-us.component';
@NgModule({
  declarations: [
    AppComponent,
    AdminsListComponent,
    AppNavBarComponentComponent,
    CreateAdminComponent,
    UpdateAdminComponent,
    AdminViewComponent,
    LoginComponentComponent,
    UserCablistComponent,
    CabListComponent,
    UpdateCabComponent,
    CreateCabComponent,
    FilterCabComponent,
    FilteredCablistComponent,
    UserFiltercabComponent,
    UserFiltercablistComponent,
    CreateTripComponent,
    TripListComponent,
    CreateDriverComponent,
    DriverListComponent,
    UpdateDriverComponent,
    DriverDetailsComponent,
    TripDetailsComponent,
    CreateCustomerComponent,
    CustomerTableComponent,
    UpdateCustomerComponent,
    ViewCustomerComponent,
    AdminInterfaceComponent,
    UserInterfaceComponent,
    ViewHistoryComponent,
    AboutUsComponent,
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
  
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

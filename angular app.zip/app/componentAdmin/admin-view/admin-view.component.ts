import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Admin } from 'src/app/model/admin';
import { AdminServiceService } from 'src/app/service/admin-service.service';

@Component({
  selector: 'app-admin-view',
  templateUrl: './admin-view.component.html',
  styleUrls: ['./admin-view.component.css']
})
export class AdminViewComponent implements OnInit {
userId:number;
admin:Admin=new Admin();
  constructor(private admServ:AdminServiceService,private route:ActivatedRoute) { 
    
  }

  ngOnInit() {
    this.userId=this.route.snapshot.params['id'];
    this.admServ.getAdminById(this.userId).subscribe(
      data=>{
        this.admin=data;
      },error=>{
        console.log(error);
      }
    );

  }


}

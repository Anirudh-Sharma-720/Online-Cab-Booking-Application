import { Component, OnInit } from '@angular/core';
import { TripBooking } from 'src/app/model/trip-booking';
import { TripServiceService } from 'src/app/service/trip-service.service';
import { Router } from '@angular/router';
import { Cab } from 'src/app/model/cab';

@Component({
  selector: 'app-create-trip',
  templateUrl: './create-trip.component.html',
  styleUrls: ['./create-trip.component.css']
})
export class CreateTripComponent implements OnInit {

  trip: TripBooking = new TripBooking();
  cab:Cab=new Cab();
  tripId:number;
  constructor(private tripService: TripServiceService,
     private router: Router) { }
    
  ngOnInit(): void {
if(JSON.parse(localStorage.getItem('cab'))!=null){
  console.log(this.cab);
  this.cab=JSON.parse(localStorage.getItem('cab'));
  }

     this.trip.cab=this.cab;
     
  }

  saveTrip(){
    this.trip.customerId=JSON.parse(localStorage.getItem('userIdd'));
  
        this.tripService.createTrip(this.trip).subscribe( data =>{
          console.log(data);
          
          this.trip=data as TripBooking;
          console.log(this.trip);
          this.router.navigate(['trip-details/',this.trip.tripBookingId]);
        },
        error => {console.log(error)});
      
      
  }

 
  onSubmit(){
        console.log(this.trip);
        this.saveTrip();
  }
}